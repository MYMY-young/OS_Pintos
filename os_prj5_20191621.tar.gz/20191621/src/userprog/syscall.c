#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include <user/syscall.h>
#include "devices/input.h"
#include "devices/shutdown.h"
#include "filesys/directory.h"
#include "filesys/inode.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "threads/interrupt.h"
#include "threads/malloc.h"
#include "threads/synch.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "userprog/pagedir.h"
#include "userprog/process.h"

#define MAX_ARGS 3
#define USER_VADDR_BOTTOM ((void *) 0x08048000)

static void syscall_handler (struct intr_frame *);
int user_to_kernel_ptr(const void *vaddr);
void get_arg (struct intr_frame *f, int *arg, int n);
void check_valid_ptr (const void *vaddr);
void check_valid_buffer (void* buffer, unsigned size);
void check_valid_string (const void* str);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  int arg[MAX_ARGS];
  int esp = user_to_kernel_ptr((const void*) f->esp);
  check_address((void*)f->esp);
  switch (* (int *) esp)
    {
    case SYS_HALT:
      
	halt(); 
	break;
      
    case SYS_EXIT:
      
	check_address(f->esp+4);
	get_arg(f, &arg[0], 1);
	exit(*(uint32_t*)(f->esp+4));
	break;
      
    case SYS_EXEC:
      
	check_address(f->esp+4);
	get_arg(f, &arg[0], 1);
	check_valid_string((const void *) arg[0]);
	arg[0] = user_to_kernel_ptr((const void *)arg[0]);
	f->eax = exec((const char *) arg[0]); 
	break;
      
    case SYS_WAIT:
      
	check_address(f->esp+4);
	get_arg(f, &arg[0], 1);
	f->eax = wait(arg[0]);
	break;
      
    case SYS_CREATE:
      
	check_address(f->esp+16);
	check_address(f->esp+20);
	get_arg(f, &arg[0], 2);
	check_valid_string((const void *) arg[0]);
	arg[0] = user_to_kernel_ptr((const void *) arg[0]);
	f->eax = create((const char *)arg[0], (unsigned) arg[1]);
	break;
      
    case SYS_REMOVE:
      
	check_address(f->esp+4);
	get_arg(f, &arg[0], 1);
	check_valid_string((const void *) arg[0]);
	arg[0] = user_to_kernel_ptr((const void *) arg[0]);
	f->eax = remove((const char *) arg[0]);
	break;
      
    case SYS_OPEN:
      
	check_address(f->esp+4);
	get_arg(f, &arg[0], 1);
	check_valid_string((const void *) arg[0]);
	arg[0] = user_to_kernel_ptr((const void *) arg[0]);
	f->eax = open((const char *) arg[0]);
	break; 		
      
    case SYS_FILESIZE:
      
	check_address(f->esp+4);
	get_arg(f, &arg[0], 1);
	f->eax = filesize(arg[0]);
	break;
      
    case SYS_READ:
      
	check_address(f->esp+20);
	check_address(f->esp+24);
	check_address(f->esp+28);
	get_arg(f, &arg[0], 3);
	check_valid_buffer((void *) arg[1], (unsigned) arg[2]);
	arg[1] = user_to_kernel_ptr((const void *) arg[1]);
	f->eax = read(arg[0], (void *) arg[1], (unsigned) arg[2]);
	break;
      
    case SYS_WRITE:
       
	check_address(f->esp+20);
	check_address(f->esp+24);
	check_address(f->esp+28);
	get_arg(f, &arg[0], 3);
	check_valid_buffer((void *) arg[1], (unsigned) arg[2]);
	arg[1] = user_to_kernel_ptr((const void *) arg[1]);
	f->eax = write(arg[0], (const void *) arg[1],
		       (unsigned) arg[2]);
	break;
      
    case SYS_SEEK:
      
	check_address(f->esp+16);
	check_address(f->esp+20);
	get_arg(f, &arg[0], 2);
	seek(arg[0], (unsigned) arg[1]);
	break;
       
    case SYS_TELL:
       
	check_address(f->esp+4);
	get_arg(f, &arg[0], 1);
	f->eax = tell(arg[0]);
	break;
      
    case SYS_CLOSE:
       
	check_address(f->esp+4);
	get_arg(f, &arg[0], 1);
	close(arg[0]);
	break;
      
    case SYS_FIBO:
	check_address(f->esp+4);
	f->eax = fibonacci((int)*(uint32_t*)(f->esp+4));
	break;

    case SYS_MAXFOURINT:
	check_address(f->esp+28);
	check_address(f->esp+32);
	check_address(f->esp+36);
	check_address(f->esp+40);
	f->eax = max_of_four_int((int)*(uint32_t*)(f->esp+28),(int)*(uint32_t*)(f->esp+32),(int)*(uint32_t*)(f->esp+36),(int)*(uint32_t*)(f->esp+40));
	break;

    case SYS_CHDIR:
      
	check_address(f->esp+4);
	get_arg(f, &arg[0], 1);
	check_valid_string((const void *) arg[0]);
	arg[0] = user_to_kernel_ptr((const void *) arg[0]);
	f->eax = chdir((const char *) arg[0]);
	break;
      
    case SYS_MKDIR:
      
	check_address(f->esp+4);
	get_arg(f, &arg[0], 1);
	check_valid_string((const void *) arg[0]);
	arg[0] = user_to_kernel_ptr((const void *) arg[0]);
	f->eax = mkdir((const char *) arg[0]);
	break;
      
    case SYS_READDIR:
      
	check_address(f->esp+16);
	check_address(f->esp+20);
	get_arg(f, &arg[0], 2);
	check_valid_string((const void *) arg[1]);
	arg[1] = user_to_kernel_ptr((const void *) arg[1]);
	f->eax = readdir(arg[0], (char *) arg[1]);
	break;
      
    case SYS_ISDIR:
      
	check_address(f->esp+4);
	get_arg(f, &arg[0], 1);
	f->eax = isdir(arg[0]);
	break;
      
    case SYS_INUMBER:
      
	check_address(f->esp+4);
	get_arg(f, &arg[0], 1);
	f->eax = inumber(arg[0]);
	break;
      
    }
}

void check_address(const void *check){
        if(!is_user_vaddr(check)){
                exit(-1);
        }  
  
        if(pagedir_get_page(thread_current()->pagedir,check) == NULL){
		if(!verify_stack(check,check))exit(-1);
	}
}

bool chdir (const char* dir)
{
  return filesys_chdir(dir);
}

bool mkdir (const char* dir)
{
  return filesys_create(dir, 0, true);
}

bool readdir (int fd, char* name)
{
  struct pp_file *file;
  file  = process_get_file(fd);

  if(file == NULL) return false;
  if (file->isdir == NULL) return false;
  if (dir_readdir(file->dir, name) == NULL) return false;
  return true;
}

bool isdir (int fd)
{
  struct pp_file *file = process_get_file(fd);
  if (file==NULL)return false;
  return file->isdir;
}

int inumber (int fd)
{
  struct pp_file *file;
  block_sector_t inumber;

  file = process_get_file(fd);
  if (file == NULL) return -1;
  if (file->isdir){
      inumber = inode_get_inumber(dir_get_inode(file->dir));
  }
  else{
      inumber = inode_get_inumber(file_get_inode(file->file));
  }
  return inumber;
}

void halt (void){
  shutdown_power_off();
}

void exit (int status)
{
 
  struct thread *t;
  t  = thread_current();
  printf("%s: exit(%d)\n", thread_name(),status);

  if (thread_alive(t->parent) && t->cp){
      t->cp->status = status;
    }
  thread_exit();
}

tid_t exec (const char *cmd_line)
{
  tid_t return_pid = process_execute(cmd_line);
  struct child_process* tt;
  tt  = get_child_process(return_pid);
  if (!tt) return -1;
  if (tt->load == NOT_LOADED){
      sema_down(&tt->load_sema);
  }
  if (tt->load == LOAD_FAIL){
      remove_child_process(tt);
      return -1;
  }
  return return_pid;
}

int wait (tid_t tid){
  return process_wait(tid);
}

bool create (const char *file, unsigned initial_size){
  if(file == NULL) exit(-1);
  return filesys_create(file, initial_size, false);
}

bool remove (const char *file){

  if(file == NULL) exit(-1);
  return filesys_remove(file);
}

int open (const char *file)
{
 // if(file == NULL) exit(-1);
  struct file *open_f;
  open_f = filesys_open(file);
  int fd;
  if (open_f == NULL) return -1; 


  if (inode_is_dir(file_get_inode(open_f))){
      fd = process_add_dir((struct dir *) open_f);
  }
  else{
      fd = process_add_file(open_f);
  }
  return fd;
}

int filesize (int fd)
{
  struct pp_file *file;
  file = process_get_file(fd);
  if (file == NULL) return -1;
  
  if (file->isdir) return -1;
  
  return file_length(file->file);
  
}

int read (int fd, void *buffer, unsigned size)
{
 // if(!is_user_vaddr(buffer))exit(-1);

  if (fd == STDIN_FILENO){
      for (int i = 0; i < size; i++)
	{
	  *((char*)buffer++) = input_getc();
	}
      return size;
  }
  struct pp_file *file = process_get_file(fd);
  if (file==NULL) return -1;
  if (file->isdir) return -1;
  
  return file_read(file->file, buffer, size);
}

int write (int fd, const void *buffer, unsigned size)
{
  if (fd == STDOUT_FILENO)
    {
      putbuf(buffer, size);
      return size;
    }
  struct pp_file *file = process_get_file(fd);
  if (file == NULL) return -1;
  if (file->isdir) return -1;
 
  return file_write(file->file, buffer, size);
}

int fibonacci(int n){
     if (n<2)
	return n;
     int a = 0;
     int b = 1;
     int temp = 0;
     for(int i=0;i<n-1;i++){
	temp = b;
        b = a+b;
        a = temp;
	
     }
     return b;

}

int max_of_four_int(int a, int b, int c, int d){
	int max = a;

	if(b>max) max = b;
	if(c>max) max = c;
	if(d>max) max = d;
	return max;
}



void seek (int fd, unsigned position)
{
  struct pp_file *file;
  file  = process_get_file(fd);
  if (file == NULL) return;
  if (file->isdir) return;
  file_seek(file->file, position);
}

unsigned tell (int fd)
{
  struct pp_file *file = process_get_file(fd);
  if (file == NULL) return -1;
  if (file->isdir) return -1;
  return file_tell(file->file);
}

void close (int fd)
{
  process_close_file(fd);
}

void check_valid_ptr (const void *vaddr)
{
  if (!is_user_vaddr(vaddr) || vaddr < USER_VADDR_BOTTOM) exit(-1);
}

int user_to_kernel_ptr(const void *vaddr)
{
  check_valid_ptr(vaddr);
  void *ptr = pagedir_get_page(thread_current()->pagedir, vaddr);
  if (!ptr)
    {
      exit(ERROR);
    }
  return (int) ptr;
}

struct child_process* add_child_process (int pid)
{
  struct child_process* child = malloc(sizeof(struct child_process));
  if (child == NULL) return NULL;
  child->wait = false;
  child->exit = false;
  child->load = NOT_LOADED;
  child->pid = pid;
  sema_init(&child->load_sema, 0);
  sema_init(&child->exit_sema, 0);
  list_push_back(&thread_current()->child_list,&child->elem);
  return child;
}

struct child_process* get_child_process (int pid)
{
  struct thread *cur;
  struct list_elem *ele;
  cur  = thread_current();

  for (ele = list_begin (&cur->child_list); ele != list_end (&cur->child_list);ele = list_next(ele)){
          struct child_process *child = list_entry (ele, struct child_process, elem);
          if (pid == child->pid) return child;
  }
  return NULL;
}

void remove_child_process (struct child_process *child)
{
  list_remove(&child->elem);
  free(child);
}

void remove_child_processes (void)
{
  struct thread *cur;
  struct list_elem *e,*next;
  cur = thread_current();
  
  for (e = list_begin(&cur->child_list);e != list_end (&cur->child_list);){
      next = list_next(e);
      struct child_process *child = list_entry (e, struct child_process,elem);
      list_remove(&child->elem);
      free(child);
      e = next;

    }
}

void get_arg (struct intr_frame *f, int *arg, int n)
{
  int *ptr;
  for (int i = 0; i < n; i++){
      ptr = (int *) f->esp + i + 1;
      check_valid_ptr((const void *) ptr);
      arg[i] = *ptr;
   }
}

void check_valid_buffer (void* buffer, unsigned size)
{
  char* local_buffer = (char *) buffer;
  for (int i = 0; i < size; i++){
      check_valid_ptr((const void*) local_buffer);
      local_buffer++;
   }
}

void check_valid_string (const void* str)
{
  while (1){
     if(*(char*) user_to_kernel_ptr(str) == 0) break; 
     str = (char *) str + 1;
   }
}
