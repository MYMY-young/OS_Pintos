#ifndef USERPROG_PROCESS_H
#define USERPROG_PROCESS_H

#include "threads/thread.h"
//#include "filesys/directory.c"

struct pp_file{
    
	struct file *file;
	struct dir *dir;
	bool isdir;
	int fd;
	struct list_elem elem;

};


tid_t process_execute (const char *file_name);
int process_wait (tid_t);
void process_exit (void);
void process_activate (void);
void file_name_parse(const char* file_name,char *cmd);


int setup_argc(const char *file_name);
void stack_esp(void **esp, const char *file_name);
bool verify_stack(void* fault_addr, void *esp);

#endif /* userprog/process.h */
