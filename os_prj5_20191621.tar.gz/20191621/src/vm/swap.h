#include <stdint.h>
#include "devices/block.h"
#include <debug.h>
#include <bitmap.h>
#include <stdlib.h>
struct block *swap_block;
struct lock swap_lock;
bool *swapped;

void swap_init(void);
void swap_in(void *userpage, void*kpage, int swap_index);
int swap_out(void *upage, void *kpage);
void swap_free(uint32_t swap_idx);
