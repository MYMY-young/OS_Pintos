#include "swap.h"
#include "threads/vaddr.h"
#include "threads/thread.h"
#include "threads/palloc.h"
#include "page.h"
//#include "frame.h"
#include <stdlib.h>

#define SPP (PGSIZE/BLOCK_SECTOR_SIZE)
#define SIZE_OF_SWAP_IDX (block_size(swap_block)/SPP)

void init_swap(){
	swap_block = block_get_role(BLOCK_SWAP);

	int block_num=block_size(swap_block)/SPP;
	if(swap_block)
	{
		
		swapped = malloc(SIZE_OF_SWAP_IDX);
		for(int i=0; i<block_num; i++)
		{
			swapped[i]=false;
		}
	}
	
}

int swap_out(void *upage, void *kpage)
{

	ASSERT(is_user_vaddr(upage));
	
	int index;
	int s_index;
	int block_num=block_size(swap_block)/SPP;
	for(index=0; index<block_num; index++)
	{
		if(swapped[index]==false)
			break;
	}
	
	s_index=SPP*index;
	for(int i=0; i<SPP;i++)
	{
		block_write(swap_block, s_index+i, BLOCK_SECTOR_SIZE*i+kpage);
	}

	swapped[index]=true;

	return index;
}
/*void swap_in(void *userpage, uint32_t swap_idx){
	ASSERT(is_user_vaddr(userpage));
	
	void *kerpage = palloc_get_page(PAL_USER);
	while(kerpage == NULL){
		page_evict_frame();
		kerpage = palloc_get_page(PAL_USER);
	}
	struct page_entry *pp = page_get_entry(userpage, thread_tid());
	
	ASSERT(pp != NULL);
	ASSERT(kerpage != NULL);
	
	lock_acquire(&swap_lock);
	
	for(int i=0; i<SPP;i++){
		block_read(swap_block, swap_idx * SPP + i, kerpage+i*BLOCK_SECTOR_SIZE);
	}
	pagedir_set_page (thread_current()->pagedir, userpage, kerpage, pp->writable);
	page_set_swap(userpage, kerpage, thread_tid());
	swapped[swap_idx] = false;
	lock_release(&swap_lock);
	return;
}*/
void swap_in(void *upage, void *kpage, int swap_index)
{
	ASSERT(is_user_vaddr(upage));
	struct thread* curr = thread_current();
	//struct hash *pt = &(curr->page_table);
//	struct page_entry *pp = get_page_entry(pt, upage);
//	if(swapped[swap_index])
//	{
//		int s_index=SPP*swap_index;
//		for(int i=0; i<SPP; i++)
//		{
//			block_read(swap_block, s_index+i, BLOCK_SECTOR_SIZE*i+kpage);
//		}
//		swapped[swap_index]=false;

//		pp->swap_index=-1;
//		pagedir_set_page(curr->pagedir, pg_round_down(upage), pg_round_down(kpage), pp->writable);
//	}
}
/*
void swap_free(uint32_t swap_idx){
	lock_acquire(&swap_lock);
	swapped[swap_idx] = false;
	lock_release(&swap_lock);
	
}*/
