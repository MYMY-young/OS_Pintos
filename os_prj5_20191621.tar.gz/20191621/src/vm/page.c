#include "page.h"
#include "swap.h"
#include "threads/palloc.h"
#include "threads/thread.h"
#include "userprog/pagedir.h"
#include "threads/vaddr.h"
#include "threads/interrupt.h"

//struct hash pt;

/*
void init_page(struct hash *PT){
	struct page_entry* page_entry = hash_entry(p,struct page_entry,elem);
	unsigned page_hash = hash_bytes(&page_entry->vaddr, sizeof(page_entry->vaddr));
	bool page_flag;
	hash_init(PT,page_hash,page_hash_less_func,NULL);

}
*/
unsigned page_hash_less_func(const struct hash_elem *p, void *aux);
//void page_hash_less_func(const struct hash_elem *a, const struct hash_elem *b, void *aux);
static bool pt_init(void *upage, void *kpage, bool writable);
/*void page_table_init(){
	hash_init(&pt, &page_hash_fun,&page_hash_less_func,NULL);
	frame_for_swap = palloc_get_page(PAL_USER);
	lock_init(&page_lock);
}
*/

bool page_less_func(const struct hash_elem *page1, const struct hash_elem *page2, void *aux)
{
	bool result = true;
	if (hash_entry(page1,struct page_entry, elem)->vaddr >= hash_entry(page2, struct page_entry, elem)->vaddr)
		result = false;
	return result;
}

unsigned page_hash_less_func(const struct hash_elem *p, void *aux)
{
	struct page_entry* page_entry = hash_entry(p, struct page_entry, elem);
	return hash_bytes(&page_entry->vaddr, sizeof(page_entry->vaddr));
}


void init_page_table(struct hash* page_table){
	hash_init(page_table, page_hash_less_func,page_less_func, NULL);
}
/*void page_hash_less_func(const struct hash_elem *a, const struct hash_elem *b, void *aux){
	struct page_entry* p1 = hash_entry(a,struct page_entry, elem);
	struct page_entry* p2 = hash_entry(b,struct page_entry, elem);
	
	uint32_t idx = (uint32_t)(p1->vpn);
	idx = idx<<12;
	idx = idx + p1->pid;
	ASSERT(p1->pid < 0x1000);
	
	uint32_t idx2 = (uint32_t)(p2->vpn);
	idx2 = idx2<<12;
	idx2 = idx2 + p2->pid;
	ASSERT(p2->pid < 0x1000);
	
	
	if(idx < idx2) return true;
	else return false;
}

unsigned page_hash_fun (const struct hash_elem *e, void *aux){
	struct page_entry* p = hash_entry(e, struct page_entry, elem);
	
	uint32_t idx = (uint32_t)(p->vpn);
	idx = idx<<12;
	idx = idx + p->pid;
	ASSERT(p->pid < 0x1000);
	
	return hash_bytes(&idx,sizeof idx);
}
*/
/*
struct page_entry *page_get_entry (void *vaddr, uint32_t pid){
	lock_acquire(&page_lock);
	struct hash_elem *e = get_hash_element(vaddr, pid);
	lock_release(&page_lock);
	
	if(e != NULL) return hash_entry(e, struct page_entry, elem);
	else return NULL;
}
*/

struct page_entry* get_page_entry(struct hash *pt, void *vaddr)
{
	struct page_entry page;
	page.vaddr=pg_round_down(vaddr);
	struct hash_elem *temp=hash_find(pt, &page.elem);
	if(temp!=NULL)
		return hash_entry(temp, struct page_entry, elem);
	else
		return NULL;

}


/*
struct hash_elem *get_hash_element(void *vaddr, uint32_t pid){
	struct page_entry pp;
	pp.vpn = ((uint32_t)vaddr & 0xfffff000) >> 12;
	pp.pid = pid;
	return hash_find(&pt, &pp.elem);
}
*/
bool page_insert (void *vaddr, void *paddr, bool writable){

	struct page_entry *pp=(struct page_entry*)malloc(sizeof(struct page_entry));
	pp->vaddr=pg_round_down(vaddr);
	pp->paddr=pg_round_down(paddr);
	pp->swap_index=-1;
	pp->writable=writable;

	/*struct hash *page_table=&(thread_current()->page_table);
	if(!hash_find(page_table, &pp->elem))
		hash_insert(page_table, &pp->elem);
	else
	{
		pp=hash_entry(hash_find(page_table, &pp->elem), struct page_entry, elem);
		pp->swap_index=-1;
	}
	return true;


*/
return true;
//	ASSERT(pp != NULL);
/*	
	if(pp == NULL) return false;
	
	if(kerpage != frame_for_swap){
		pp->ppn = ((uint32_t)kerpage & 0xfffff000) >> 12;
		pp->swap_index = -1;
		pp->on_disk = false;
	}
	else{
		pp->ppn = 0;
		pp->swap_index = swap_out(kerpage);
		pp->on_disk = true;
	}
	
	pp->pinned = false;
	pp->vpn = ((uint32_t)userpage & 0xfffff000) >> 12;
	pp->pid = thread_tid();
	pp->writable = writable;
	pp->elem.list_elem.next = NULL;
	pp->elem.list_elem.prev = NULL;
	pp->t = thread_current();
//	lock_acquire(&page_lock);
//	list_push_back(&(thread_current()->list),&pp->elem);
//	if(hash_insert(&pt,&(pp->elem))==NULL) ASSERT(pp);
//	lock_release(&page_lock);
*/	
}

bool page_delete(struct hash *page_table, void *vaddr){

	bool result = false;
	struct page_entry *page=get_page_entry(page_table, vaddr);
	if(page!=NULL){
		hash_delete(page_table, &page->elem);
		result = true;
	}
	return result;

}
void page_delete_func(struct hash_elem* e, void* aux)
{
	free(hash_entry(e, struct page_entry, elem));
}


void page_table_destroy(struct hash *page_table)
{
	hash_destroy(page_table, page_delete_func);
}
/*

bool page_destroy (uint32_t pid){
	lock_acquire(&page_lock);
	bool del = true;
	while (del == true){
		del = false;
		struct hash_iterator iter;
		
		hash_first(&iter, &pt);
		while(hash_next(&iter)){
			struct page_entry *pp = hash_entry(hash_cur(&iter), struct page_entry, elem);
			if(pp->pid == pid){
				if(pp->swap_index != -1) swap_free(pp->swap_index);
				struct hash_elem *e = hash_cur(&iter);
				hash_delete(&pt, &pp->elem);
				free(hash_entry(e, struct page_entry, elem));
				del = true;
				break;
			}
		}
	}
	lock_release(&page_lock);
	return true;
}

void page_set_swap(void *userpage, void *kerpage, uint32_t pid){
	struct hash_elem *e = get_hash_element(userpage, pid);
	ASSERT(e != NULL);
	struct page_entry *pp = hash_entry(e, struct page_entry, elem);
	pp->ppn = ((uint32_t)kerpage & 0xfffff000) >> 12;
	pp->swap_index = -1;
}
*/

/*
bool page_evict_frame(){
	struct hash_iterator iter;
	struct thread* curr = thread_current();
	struct page_entry *pp = NULL;
	
	while(1){
		hash_first(&iter,&pt);
		while(hash_next(&iter)){
			pp = hash_entry (hash_cur(&iter), struct page_entry, elem);
			if(pp->pinned == false && pp->ppn != 0){
				if(thread_get_ticks()%3==0)continue;
//				pp->swap_index = swap_out(pp->ppn << 12);
				pagedir_clear_page(pp->t->pagedir, (void*)(pp->vpn << 12));
				palloc_free_page((void*)(pp->ppn << 12));
				pp->ppn = 0;
				return true;
			}
		}
	}
	PANIC("page_evict_frame fail!");
}*/
/*
bool page_swap_in_and_pinning(void *userpage, uint32_t pid){
	struct page_entry *pp = page_get_entry(userpage, pid);
	lock_acquire(&swap_lock);
	lock_release(&swap_lock);
	
	if(pp == NULL)return false;
	pp->pinned = true;

	if(pp->ppn != 0)return true;
	
	swap_in(userpage, pp->swap_index);
	return true;


}

void page_pinning_buffers(void *buffer_, unsigned size_){
	uint32_t buffer = ((uint32_t) buffer_ >> 12) << 12;
	int size = size_ + (uint32_t)buffer_ - buffer;
	uint32_t pid = thread_tid();
	
	while(size > 0){
		page_swap_in_and_pinning((void*)buffer, pid);
		buffer = buffer + PGSIZE;
		size = size - PGSIZE;
	}


}

void page_unpinning_buffers(void *buffer_, unsigned size_){

	uint32_t buffer = ((uint32_t) buffer_ >> 12) <<12;
	int size = size_ + (uint32_t) buffer_ - buffer;
	uint32_t pid = thread_tid();
	
	while(size>0){
		struct page_entry *pp = page_get_entry(buffer, pid);
		ASSERT(pp != NULL);
		pp->pinned = false;
		buffer += PGSIZE;
		size = size - PGSIZE;
	}
}*/
/*
int page_swap_in_all(){
	struct thread *cur = thread_current();
	struct hash_iterator iter;
	void *p;
	int cnt = 0;
	int res = 0;
	hash_first (&iter, &pt);
	while(hash_next(&iter)){
		struct page_entry *pp = hash_entry(hash_cur(&iter), struct page_entry, elem);
		if(pp->ppn == 0){
			swapped[pp->swap_index] = true;
		}
	}
	return res;
}
*/
void stack_growth(void* upage){
/*	struct page_entry * new_pg = page_lookup(upage);
  if(!new_pg) {
    // Create the stack page, set its members, and add it to the SPT
    new_pg = malloc(sizeof(struct page_entry));
    ASSERT(new_pg != NULL);
    new_pg->vaddr = upage;
    new_pg->writable = true;
    new_pg->thr = thread_current();
    new_pg->pinned = false;
    lock_acquire(&new_pg->thr->spt_lock);
    ASSERT(hash_insert(&thread_current()->page_table, 
                       &new_pg->supp_page_table_elem) == NULL);
    // if(hash_insert(&thread_current()->supp_page_table, 
    //     &new_pg->supp_page_table_elem)) {
    //   free(new_pg);
    //   return;
    //}
    lock_release(&new_pg->thr->spt_lock);
  } 
  uint8_t *kpage = falloc_get_page (PAL_USER, upage);
  if (!install_page(upage, kpage, new_pg->writable)){
    falloc_free_page(upage);
  }*/
  return;
}
	
static bool pt_init(void *upage, void *kpage, bool writable){
	struct thread *tt = thread_current();
	return (pagedir_get_page(tt->pagedir, upage) == NULL && pagedir_set_page(tt->pagedir,upage,kpage,writable));
}
/*
struct page *alloc_page(enum palloc_flags flags)
{
	struct page *new_page;
	void *kaddr;
	if((flags & PAL_USER) == 0)
		return NULL;
	kaddr = palloc_get_page(flags);
	
	while(kaddr == NULL)
	{
		try_to_free_pages();
		kaddr = palloc_get_page(flags);
	}
	new_page = malloc(sizeof(struct page));
	if(new_page == NULL)
	{
		palloc_free_page(kaddr);
		return NULL;
	}
	
	new_page->kaddr  = kaddr;
	new_page->pg_thread = thread_current();

	add_page_to_lru_list(new_page);
	return new_page;
}
*/
/*
void free_page(void *kaddr)
{
	struct list_elem *element;
	struct page *lru_page;
	lock_acquire(&lru_list_lock);

	for(element = list_begin(&lru_list); element != list_end(&lru_list); element = list_next(element))
	{
		lru_page = list_entry(element, struct page, lru);
		
		if(lru_page->kaddr == kaddr)
		{
			__free_page(lru_page);
			break;
		}
	}
	lock_release(&lru_list_lock);
}*/
