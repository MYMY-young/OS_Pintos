#include "filesys/buffer_cache.h"
#include "filesys/filesys.h"
#include "threads/malloc.h"
#include "threads/thread.h"
#include "threads/synch.h"

void bc_init (void)
{
  list_init(&bc_list);
  lock_init(&bc_lock);
 bc_size=0; 

}

struct cache_entry* block_in_cache (block_sector_t sector)
{
  struct cache_entry *c;
  struct list_elem *e;
  for (e = list_begin(&bc_list); e != list_end(&bc_list);e = list_next(e)){
      c = list_entry(e, struct cache_entry, elem);
      if (c->sector == sector)
	{
	  return c;
	}
    }
  return NULL;
}

struct cache_entry* bc_block_get (block_sector_t sector, bool dirty)
{
  lock_acquire(&bc_lock);
  struct cache_entry *ce = block_in_cache(sector);
  if (ce){
      ce->open_cnt++;
      ce->dirty |= dirty;
      ce->accessed = true;
      lock_release(&bc_lock);
      return ce;
    }
  ce = bc_block_evict(sector, dirty);
  if (ce == NULL)
    {
      PANIC("Not enough memory for buffer cache.");
    }
  lock_release(&bc_lock);
  return ce;
}

struct cache_entry* bc_block_evict (block_sector_t sector, bool dirty)
{
  struct cache_entry *ce;
  if (bc_size < 64)
    { //cache size 64 sector size
      bc_size++;
      ce = malloc(sizeof(struct cache_entry));
      if (ce == NULL) return NULL;
      ce->open_cnt = 0;
      list_push_back(&bc_list, &ce->elem);
    }
  else
    {
      int flag = 0;
      while (1){
	  struct list_elem *e;
	  for (e = list_begin(&bc_list); e != list_end(&bc_list);e = list_next(e)){
	      ce = list_entry(e, struct cache_entry, elem);
	      if (ce->open_cnt > 0) continue;
	      if (ce->accessed) ce->accessed = false;
	      else{
		  if (ce->dirty){
		      block_write(fs_device, ce->sector, &ce->block);
		  }
		  flag = 1;
		  break;
	      }
	      if(flag == 1) break;
	     
	  }
          if(flag == 1) break;
	}
    }
  
  ce->open_cnt++;
  ce->sector = sector;
  block_read(fs_device, ce->sector, &ce->block);
  ce->accessed = true;
  ce->dirty = dirty;  
  return ce;
}

void bc_write_to_disk (bool halt)
{
  lock_acquire(&bc_lock);
  struct list_elem *next, *e = list_begin(&bc_list);
  while (1){
      if(e == list_end(&bc_list))break;
      next = list_next(e);
      struct cache_entry *ce = list_entry(e, struct cache_entry, elem);
      if (ce->dirty){
	  block_write (fs_device, ce->sector, &ce->block);
	  ce->dirty = false;
	}
      if (halt){
	  list_remove(&ce->elem);
	  free(ce);
	}
      e = next;
  }
  lock_release(&bc_lock);
}

void thread_func_write_back (void *aux UNUSED)
{
  while (1){
      timer_sleep(5 * TIMER_FREQ);
      bc_write_to_disk(false);
    }
}
