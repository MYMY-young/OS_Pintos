#ifndef FILESYS_INODE_H
#define FILESYS_INODE_H

#include <stdbool.h>
#include "filesys/off_t.h"
#include "devices/block.h"
#include "threads/malloc.h"
#include "threads/synch.h"
#include <list.h>

struct bitmap;

struct inode{
	struct list_elem elem;
	block_sector_t sector;
	int open_cnt;
	bool removed;
	int deny_write_cnt;
	off_t length;
	off_t read_length;
	size_t direct_index;
	size_t indirect_index;
	size_t double_indirect_index;
	bool isdir;
	block_sector_t parent;
	struct lock lock;	
	block_sector_t ptr[14];

};


void inode_init (void);
bool inode_create (block_sector_t, off_t, bool);
struct inode *inode_open (block_sector_t);
struct inode *inode_reopen (struct inode *);
block_sector_t inode_get_inumber (const struct inode *);
bool inode_is_dir (const struct inode *);
void inode_close (struct inode *);
void inode_remove (struct inode *);
off_t inode_read_at (struct inode *, void *, off_t size, off_t offset);
off_t inode_write_at (struct inode *, const void *, off_t size, off_t offset);
void inode_deny_write (struct inode *);
void inode_allow_write (struct inode *);
off_t inode_length (struct inode *);
int inode_get_open_cnt (const struct inode *inode);
block_sector_t inode_get_parent (const struct inode *inode);
bool inode_add_parent (block_sector_t parent_sector,
		       block_sector_t child_sector);
void inode_lock (const struct inode *inode);
void inode_unlock (const struct inode *inode);

#endif /* filesys/inode.h */
