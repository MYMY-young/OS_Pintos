#ifndef FILESYS_CACHE_H
#define FILESYS_CACHE_H

#include "devices/block.h"
#include "devices/timer.h"
#include "threads/synch.h"
#include <list.h>


struct list bc_list;
uint32_t bc_size;
struct lock bc_lock;

struct cache_entry {
  uint8_t block[BLOCK_SECTOR_SIZE];
  block_sector_t sector;
  bool dirty;
  bool accessed;
  int open_cnt;
  struct list_elem elem;
};

void bc_init (void);
struct cache_entry *block_in_cache (block_sector_t sector);
struct cache_entry *bc_block_get (block_sector_t sector, bool dirty);
struct cache_entry *bc_block_evict (block_sector_t sector, bool dirty);
void bc_write_to_disk (bool halt);
void thread_func_write_back (void *aux);
void thread_func_read_ahead (void *aux);
void spawn_thread_read_ahead (block_sector_t sector);

#endif /* filesys/cache.h */
