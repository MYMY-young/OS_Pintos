#include <stdio.h>

int int_sub_float(int i, int f){
	return i*(1<<14) - f;
}

int int_multi_float(int i, int f){

	return i*f;
}

int float_add_int(int f, int i){
	return f + i*(1<<14);
}

int float_multi_float(int f, int i){
	int64_t temp = f;
	temp = temp * i / (1<<14);
	return (int) temp;
}

int float_div_float(int f_1, int f_2){
	int64_t temp = f_1;
	temp = temp * (1<<14)/f_2;
	return (int) temp;
}

int float_add_float(int f_1, int f_2){
	
	return f_1 + f_2;

}

int float_sub_float(int f1, int f2){
	return f1-f2;
}
int float_div_int(int f, int i){
	return f/i;
}
