#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "devices/shutdown.h"
#include "userprog/process.h"
#include "threads/malloc.h"
#include "devices/input.h"
#include "filesys/file.h"
//#include "filesys/file.c"
#include "filesys/filesys.h"
#include "threads/vaddr.h"
#include "../syscall-nr.h"
#include <stdbool.h>
#include "filesys/off_t.h"

struct file{
	struct inode *inode;
	off_t pos;
	bool deny_write;
};
static void syscall_handler (struct intr_frame *);
int wait(tid_t tid);
tid_t exec(const char* cmd_line);
void
syscall_init (void) 
{
  lock_init(&file_lock);
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
//  printf("syscall : %d\n",*(uint32_t*)(f->esp));
//  printf ("system call!\n");
  uint32_t *esp = f->esp;
 //sys_num = *(uint32_t*)(f->esp);
 check_address((void*)esp);
 int sys_num = *esp;
// printf("syscall : %d\n",sys_num);
// arg[6];
// hex_dump(f->esp,f->esp,100,1);
 switch(sys_num){
   case SYS_HALT:
 //       printf("SYSYSYSYSYSYSYS_HHHHHAAAALLLLLTTTT\n");
        halt();
  //      printf("halllllt\n");
        break;

   case SYS_EXIT:
        //argc = 1, esp+4
       check_address(f->esp+4);
   //     printf("exxxiiittttt\n");
//        get_argument(esp,arg,1);
        exit(*(uint32_t*)(f->esp+4));
//      exit(*(uint32_t*)(f->esp+20));
     //   printf("exitttttt\n");
        break;

   case SYS_EXEC:
        //argc = 1, esp+4
          check_address(f->esp+4);
          f->eax = exec((const char*) *(uint32_t*)(f->esp+4));
 //       printf("eeeeeeexxxxxxxeeeeecccccc\n");
  //      printf("f->eax exec: %d\n",f->eax);
        break;
   case SYS_WAIT:
        //argc = 1, esp+4
        check_address(f->esp+4);
        f->eax = wait((tid_t) *(uint32_t*)(f->esp+4));
       // printf("f->eax wait : %d\n",f->eax);
        break;

   case SYS_READ: 
    //    printf("RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR\n");
        check_address(f->esp+20);
	check_address(f->esp+24);
	check_address(f->esp+28);
	f->eax = read((int)*(uint32_t*)(f->esp+20),(void*)*(uint32_t*)(f->esp+24),(unsigned)*(uint32_t*)(f->esp+28));
        break;

   case SYS_WRITE:
       // printf("WRITEEEEE");
//      f->eax = sys_write(*(int*)esp+20,(void*)esp+24,(unsigned)esp+28);
//      f->eax = write((int)*(uint32_t*)(f->esp+20),(void*)*(uint32_t*)(f->esp+24),(unsigned)*((uint32_t*)(f->esp+28)));        
//        get_argument(esp,arg,3);
//        check_address((void*)arg[1]);
       // f->eax = write(arg[0],(void*)arg[1],(unsigned)arg[2]);
 	check_address(f->esp+20);
	check_address(f->esp+24);
	check_address(f->esp+28);  
      f->eax = write((int)*(uint32_t*)(f->esp+20),(void*)*(uint32_t*)(f->esp+24),(unsigned)*(uint32_t*)(f->esp+28));
	//printf("f->eax write : %d\n",f->eax);
       // printf("WWWWWWWWWWWWWWWWWWWiWWWiWWWWWw\n");
        break;

   case SYS_FIBO:
	check_address(f->esp+4);
	f->eax = fibonacci((int)*(uint32_t*)(f->esp+4));
	break;

   case SYS_MAXFOURINT:
	check_address(f->esp+28);
	check_address(f->esp+32);
	check_address(f->esp+36);
	check_address(f->esp+40);
	f->eax = max_of_four_int((int)*(uint32_t*)(f->esp+28),(int)*(uint32_t*)(f->esp+32),(int)*(uint32_t*)(f->esp+36),(int)*(uint32_t*)(f->esp+40));
	break;

   case SYS_CREATE:
	check_address(f->esp+16);
	check_address(f->esp+20);
	f->eax = create((const char*)*(uint32_t*)(f->esp+16),(unsigned)*(uint32_t*)(f->esp+20));
	break;

   case SYS_OPEN:
	check_address(f->esp+4);
	f->eax = open((const char*)*(uint32_t*)(f->esp+4));
	break;
	
   case SYS_CLOSE:
	check_address(f->esp+4);
	close((int)*(uint32_t*)(f->esp+4));
	break;
	
   case SYS_REMOVE:
	check_address(f->esp+4);
	f->eax = (bool)remove((const char*)*(uint32_t*)(f->esp+4));
	break;
	
   case SYS_FILESIZE:
	check_address(f->esp+4);
	f->eax = filesize((int)*(uint32_t*)(f->esp+4));
	break;

   case SYS_SEEK:
	check_address(f->esp+16);
	check_address(f->esp+20);
	seek((int)*(uint32_t*)(f->esp+16),(unsigned)*(uint32_t*)(f->esp+20));
	break;
   case SYS_TELL:
	check_address(f->esp+4);
	f->eax = tell((int)*(uint32_t*)(f->esp+4));
 }






//  thread_exit ();
}

void check_address(const void *check){
        if(!is_user_vaddr(check)){
                exit(-1);
        }   
}



/*

void get_argument(void *esp, int *arg, int count){
        int i;
        void *pointer = esp + 4;
        if(count >0){
                for(i=0;i<count;i++){
                        check_address(pointer);
                        arg[i] = *(int*)pointer;
                        pointer = pointer + 4;
                }
        }
}*/
void halt(void){
        shutdown_power_off();
}
void exit(int status){
	struct list_elem *list;	
	struct thread *t;
     
	printf("%s: exit(%d)\n", thread_name(),status);
	
	thread_current()->exit_code = status;
	
	for(int i=3;i<128;i++){
		if(thread_current()->fd[i] !=NULL) close(i);
	}
	for(list = list_begin(&thread_current()->child_list);list != list_end(&thread_current()->child_list);list=list_next(list)){
		t = list_entry(list,struct thread, child_elem);
		process_wait(t->tid);
	}
	thread_exit();
}
int write(int fd,const void *buffer, unsigned size){
	lock_acquire(&file_lock);
	if(fd == STDOUT){
		putbuf(buffer,size);
		lock_release(&file_lock);
		return size;
	}
	else if(fd > 2){	
		if(thread_current()->fd[fd]==NULL){
			lock_release(&file_lock);
			exit(-1);
		}
		struct file * cc = thread_current()->fd[fd];
		if(cc->deny_write){
			file_deny_write(thread_current()->fd[fd]);
		}
		size= file_write(thread_current()->fd[fd],buffer,size);
	}

	lock_release(&file_lock);
	return size;
}
tid_t exec(const char *cmd_line){
    //    tid_t tid;
  //      struct thread *child;
//        char *copy;
        //process_execut()함수를 호출해서 자식 프로세스 생성
//        if((tid = (tid_t)process_execute(cmd_line)) == TID_ERROR)
 //               return TID_ERROR;
//        copy = palloc_get_page (0);
//        if(copy == NULL)
 //               return TID_ERROR;

  //      strlcpy(copy,cmd_line,PGSIZE);
//      tid = thread_create(file_name,PRI_DEFAULT,start_process,copy);
//      if(tid == TID_ERROR){
//              palloc_free_page(copy);
//      } 
 //     child = get_child(tid);
  //    ASSERT(child);
    
    //  sema_down (&child -> sema_ready);        
     // if(!child->load)
      //        return TID_ERROR;
       // return tid;
//      return process_execute(cmd_line);
//      struct file *file = NULL;
// 	int index = 0;
//	printf("cmd_line : %s\n",cmd_line);
//	char temp[256];
//	file_name_parse(temp,cmd_line);
//	file = filesys_open(temp);
//	if(file == NULL)
//		return -1;
//	tid_t result = process_execute(cmd_line);
//	return (tid_t)result;
	struct file *f;
	int i=0;
	char file_name[128];
	while(cmd_line[i] != ' ' && cmd_line[i]!='\0'){
		file_name[i] = cmd_line[i];
		i++;
	}
	file_name[i] = '\0';
	f = filesys_open(file_name);
	if(f==NULL) return -1;
	return process_execute(cmd_line);
}


int wait (tid_t tid){
        //thread 
        //struct thread child;
        //child = thread_get_child(tid);
        //if(is_thread(child))
        //thread_yield()
        return process_wait(tid);
}



int read(int fd, void *buffer, unsigned size){
	if(!is_user_vaddr(buffer))exit(-1);
	lock_acquire(&file_lock);
	if(thread_current()->fd[fd]==NULL)exit(-1);
	int kk = -1;

        if(fd == STDIN){
                
		unsigned temp = size;
                while(temp--){
			*((char*)buffer++) = input_getc();            
		}
		kk = size;
         } 
	else if (fd>2){
		struct thread *tt = thread_current();
		if(thread_current()->fd[fd] == NULL){
			exit(-1);
		}
		kk = file_read(tt->fd[fd],buffer,size);
	}  

	lock_release(&file_lock);
	return kk;
}

int fibonacci(int n){
     if (n<2)
	return n;
     int a = 0;
     int b = 1;
     int temp = 0;
     for(int i=0;i<n-1;i++){
	temp = b;
        b = a+b;
        a = temp;
	
     }
     return b;

}

int max_of_four_int(int a, int b, int c, int d){
	int max = a;

	if(b>max) max = b;
	if(c>max) max = c;
	if(d>max) max = d;
	return max;
}

bool create(const char *file, unsigned initial_size){
	if(file == NULL) exit(-1);
	return filesys_create(file,initial_size);

}

bool remove(const char *file){
	if(file == NULL) exit(-1);
	return filesys_remove(file);

}

int filesize(int fd){
	if(thread_current()->fd[fd] == NULL) exit(-1);
	return file_length(thread_current()->fd[fd]);
}

int open(const  char *file){
	if(file==NULL) exit(-1);


	int fd = -1;
	lock_acquire(&file_lock);
	struct file *open_f = filesys_open(file);
	if(open_f == NULL) fd = -1;
	else{	
		for(int i=3;i<128;i++){
			if((thread_current()->fd[i]==NULL) && (strcmp(thread_name(),file)==0))
				file_deny_write(open_f);
			if(thread_current()->fd[i] == NULL){
				thread_current()->fd[i] = open_f;
				fd = i;	
				break;
			}
		}
	}
	lock_release(&file_lock);
	return fd;
}


void seek(int fd, unsigned position){
	if(thread_current()->fd[fd] == NULL) exit(-1);
 	file_seek(thread_current()->fd[fd],position);

}

void close(int fd){
	if(thread_current()->fd[fd]==NULL)exit(-1);
	struct file* ff = thread_current()->fd[fd];
	thread_current()->fd[fd] = NULL;
	file_close(ff);
}

unsigned tell(int fd){
 	if (thread_current()->fd[fd]==NULL) exit(-1);	
	return file_tell(thread_current()->fd[fd]);	
}
