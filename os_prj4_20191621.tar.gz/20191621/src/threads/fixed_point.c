#include <stdio.h>

int integer_subs_float(int i, int f){
	return i*(1<<14) - f;
}

int integer_multip_float(int i, int f){

	return i*f;
}

int float_addi_integer(int f, int i){
	return f + i*(1<<14);
}

int float_multip_float(int f, int i){
	int64_t temp = f;
	temp = temp * i / (1<<14);
	return (int) temp;
}

int float_divd_float(int f_1, int f_2){
	int64_t temp = f_1;
	temp = temp * (1<<14)/f_2;
	return (int) temp;
}

int float_addi_float(int f_1, int f_2){
	
	return f_1 + f_2;

}

int float_subs_float(int f1, int f2){
	return f1-f2;
}
int float_divd_integer(int f, int i){
	return f/i;
}
