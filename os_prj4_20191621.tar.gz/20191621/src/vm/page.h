#include <stdio.h>
#include <hash.h>
#include "threads/synch.h"
#include <debug.h>
#include "filesys/filesys.h"

#define VM_FILE 1
#define VM_ANON 2

enum location {
	SWAP = 001,
	MAIN_MEMORY = 002,
	DISK = 003,
	STACK = 004
};

struct page{
	void *kaddr;
	struct page_entry *vme;
	struct thread *thread;
	struct list_elem lru;
};

struct page_entry{
	uint32_t vpn; 
	uint8_t type;
	void *vaddr;
	void *paddr;
	bool writable;
	uint8_t *user_page;
	struct hash_elem elem;
	int32_t swap_index;
	
	enum location loc;
	
	struct thread *t;
	bool pinned;
	bool on_disk;
	uint32_t pid;
	uint32_t ppn;

	int is_load;
	int code_or_data;
	struct file *file;
	off_t ofs;
	uint32_t read_bytes;
	uint32_t zero_bytes;
	struct list_elem mmap_elem;
};

struct mmap_elem{
	struct page_entry *mpt;
	int mmapid;
	struct list_elem elem;
};



struct lock page_lock;
void *frame_for_swap;

bool page_evict_frame(void);
void page_table_init(void);
bool page_insert(void *vaddr, void *paddr, bool writable);
bool page_delete(struct hash *page_table, void *vaddr);
bool page_destroy(uint32_t pid);
void page_set_swap(void *userpage, void *kerpage, uint32_t pid);
struct page_entry *page_get_entry (void *vaddr, uint32_t pid);
struct hash_elem *get_hash_element(void *vaddr, uint32_t pid);
