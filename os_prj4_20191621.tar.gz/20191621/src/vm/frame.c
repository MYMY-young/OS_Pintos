#include <stdio.h>
#include <stdlib.h>
#include "threads/thread.h"
#include "threads/palloc.h"
#include "vm/page.h"
#include "vm/frame.h"
#include "vm/swap.h"
#include "threads/vaddr.h"

void init_frame()
{
	list_init(&frame_table);
}
struct frame_entry* frame_insert(void *vaddr, void *paddr, bool writable)
{
	struct frame_entry *frame=(struct frame_entry*)malloc(sizeof(struct frame_entry));
	

	frame->vaddr=pg_round_down(vaddr);
	frame->paddr=pg_round_down(paddr);
	frame->frame_thread=thread_current();
	

	if(paddr!=NULL)
	{
		list_push_back(&frame_table, &frame->elem);
		return frame;
	}

	paddr=palloc_get_page(PAL_USER);
	if(paddr==NULL)
	{
		evict_frame();
		paddr=palloc_get_page(PAL_USER);
	}
	frame->paddr=pg_round_down(paddr);
	list_push_back(&frame_table, &frame->elem);


	return frame;

}
bool frame_delete(struct frame_entry * frame)
{
	list_remove(&frame->elem);
}
struct frame_entry* get_frame_entry(void *paddr)
{
	int flag=0;
	struct list_elem *ele;
	struct frame_entry *frame;
	for(ele=list_begin(&frame_table); ele!=list_end(&frame_table); ele=list_next(ele))
	{
		frame=list_entry(ele, struct frame_entry, elem);
		if(pg_round_down(paddr)==frame->paddr)
		{
			flag = 1;
			break;
		}
	}
	if(flag == 1) return frame;
	return NULL;
}




bool evict_frame()
{
	struct list_elem *ele;
	struct frame_entry *frame;
	ele=list_begin(&frame_table);
	frame=list_entry(ele, struct frame_entry, elem);
	
	struct thread *vict = frame->frame_thread;
	struct thread *page_table = &vict->page_table;
	struct page_entry * vict_pp=get_page_entry(page_table, frame->vaddr);
	vict_pp->paddr=NULL;
	vict_pp->swap_index=swap_out(frame->vaddr, frame->paddr);

	pagedir_clear_page(frame->frame_thread->pagedir, frame->vaddr);
	palloc_free_page(frame->paddr);
	list_remove(&frame->elem);
	free(frame);
	return true;

}
