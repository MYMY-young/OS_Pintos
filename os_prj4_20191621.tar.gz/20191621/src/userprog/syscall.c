#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "devices/shutdown.h"
#include "userprog/process.h"
#include "threads/malloc.h"
#include "devices/input.h"
#include "filesys/file.h"
//#include "filesys/file.c"
#include "filesys/filesys.h"
#include "threads/vaddr.h"
#include "../syscall-nr.h"
#include <stdbool.h>
#include "filesys/off_t.h"
#include "threads/palloc.h"
#include "vm/page.h"

struct file{
	struct inode *inode;
	off_t pos;
	bool deny_write;
};
static void syscall_handler (struct intr_frame *);
int wait(tid_t tid);
tid_t exec(const char* cmd_line);
void
syscall_init (void) 
{
  lock_init(&file_lock);
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
//  printf("syscall : %d\n",*(uint32_t*)(f->esp));
//  printf ("system call!\n");
  uint32_t *esp = f->esp;
 //sys_num = *(uint32_t*)(f->esp);
 thread_current()->stack_pointer = esp;
 check_address((void*)esp);
// vm_check_address(esp,f->esp);
 int sys_num = *esp;
// printf("syscall : %d\n",sys_num);
// arg[6];
// hex_dump(f->esp,f->esp,100,1);
 switch(sys_num){
   case SYS_HALT:
 //       printf("SYSYSYSYSYSYSYS_HHHHHAAAALLLLLTTTT\n");
        halt();
  //      printf("halllllt\n");
        break;

   case SYS_EXIT:
        //argc = 1, esp+4
       check_address(f->esp+4);
   //     printf("exxxiiittttt\n");
//        get_argument(esp,arg,1);
        exit(*(uint32_t*)(f->esp+4));
//      exit(*(uint32_t*)(f->esp+20));
     //   printf("exitttttt\n");
        break;

   case SYS_EXEC:
        //argc = 1, esp+4
          check_address(f->esp+4);
          f->eax = exec((const char*) *(uint32_t*)(f->esp+4));
 //       printf("eeeeeeexxxxxxxeeeeecccccc\n");
  //      printf("f->eax exec: %d\n",f->eax);
        break;
   case SYS_WAIT:
        //argc = 1, esp+4
        check_address(f->esp+4);
        f->eax = wait((tid_t) *(uint32_t*)(f->esp+4));
       // printf("f->eax wait : %d\n",f->eax);
        break;

   case SYS_READ: 
    //    printf("RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR\n");
        check_address(f->esp+20);
	check_address(f->esp+24);
	check_address(f->esp+28);
	f->eax = read((int)*(uint32_t*)(f->esp+20),(void*)*(uint32_t*)(f->esp+24),(unsigned)*(uint32_t*)(f->esp+28));
        break;

   case SYS_WRITE:
       // printf("WRITEEEEE");
//      f->eax = sys_write(*(int*)esp+20,(void*)esp+24,(unsigned)esp+28);
//      f->eax = write((int)*(uint32_t*)(f->esp+20),(void*)*(uint32_t*)(f->esp+24),(unsigned)*((uint32_t*)(f->esp+28)));        
//        get_argument(esp,arg,3);
//        check_address((void*)arg[1]);
       // f->eax = write(arg[0],(void*)arg[1],(unsigned)arg[2]);
 	check_address(f->esp+20);
	check_address(f->esp+24);
	check_address(f->esp+28);  
      f->eax = write((int)*(uint32_t*)(f->esp+20),(void*)*(uint32_t*)(f->esp+24),(unsigned)*(uint32_t*)(f->esp+28));
	//printf("f->eax write : %d\n",f->eax);
       // printf("WWWWWWWWWWWWWWWWWWWiWWWiWWWWWw\n");
        break;

   case SYS_FIBO:
	check_address(f->esp+4);
	f->eax = fibonacci((int)*(uint32_t*)(f->esp+4));
	break;

   case SYS_MAXFOURINT:
	check_address(f->esp+28);
	check_address(f->esp+32);
	check_address(f->esp+36);
	check_address(f->esp+40);
	f->eax = max_of_four_int((int)*(uint32_t*)(f->esp+28),(int)*(uint32_t*)(f->esp+32),(int)*(uint32_t*)(f->esp+36),(int)*(uint32_t*)(f->esp+40));
	break;

   case SYS_CREATE:
	check_address(f->esp+16);
	check_address(f->esp+20);
	f->eax = create((const char*)*(uint32_t*)(f->esp+16),(unsigned)*(uint32_t*)(f->esp+20));
	break;

   case SYS_OPEN:
	check_address(f->esp+4);
	f->eax = open((const char*)*(uint32_t*)(f->esp+4));
	break;
	
   case SYS_CLOSE:
	check_address(f->esp+4);
	close((int)*(uint32_t*)(f->esp+4));
	break;
	
   case SYS_REMOVE:
	check_address(f->esp+4);
	f->eax = (bool)remove((const char*)*(uint32_t*)(f->esp+4));
	break;
	
   case SYS_FILESIZE:
	check_address(f->esp+4);
	f->eax = filesize((int)*(uint32_t*)(f->esp+4));
	break;

   case SYS_SEEK:
	check_address(f->esp+16);
	check_address(f->esp+20);
	seek((int)*(uint32_t*)(f->esp+16),(unsigned)*(uint32_t*)(f->esp+20));
	break;
   case SYS_TELL:
	check_address(f->esp+4);
	f->eax = tell((int)*(uint32_t*)(f->esp+4));

   case SYS_MMAP:
//	printf("MMAP!!!\n\n\n");
	check_address(f->esp+8);
	check_address(f->esp+4);
	f->eax = mmap(0,1024*(int)(f->esp+4), *(unsigned char **)(f->esp+8));
	break;
  
   case SYS_MUNMAP:
	check_address(f->esp+4);
	munmap(*(int*)(f->esp + 4));
	break;


 }






//  thread_exit ();
}
/*
void
vm_check_address(void *addr, void *esp)
{
	struct page_entry *vme;
	uint32_t address=(unsigned int)addr;
	uint32_t lowest_address=0x8048000;
	uint32_t highest_address=0xc0000000;
	
	if(address >= lowest_address && address < highest_address)
	{
		
		vme = get_page_entry(thread_current()->page_table,addr);
		
		if(vme == NULL)
		{
			if(addr >= esp-32){
//				if(expand_stack(addr) == false)
//					exit(-1);
			}
		//	else
//				exit(-1);
		}
	}
	else
	{
		exit(-1);
	}
}*/
void check_address(const void *check){
        if(!is_user_vaddr(check)){
                exit(-1);
        }  
  
        if(pagedir_get_page(thread_current()->pagedir,check) == NULL){
		if(!verify_stack(check,check))exit(-1);
	}
 /* Make sure the user given pointer points to user virtual address 
     space, not kernel */  
  
  struct thread *cur = thread_current();
  /* lookup the page in the spt */
//  struct page_entry *p = page_lookup(pg_round_down(check));
//  if(p == NULL) {
    /* create page if there isn't one */
//    if(check >= (PHYS_BASE - 0x800000) && check >= (cur->stack_pointer - 32)) {
 //     stack_growth(pg_round_down(check));
  //  } else
   //     exit(-1);
 // } else { 
  //  if(!p->loc == MAIN_MEMORY) {
      // if the page is not in memory, load the page
 //     bool success = load_segment(p->vaddr);
  //    if(!success)
   //     exit(-1);
  //  }
 // }	



}



/*

void get_argument(void *esp, int *arg, int count){
        int i;
        void *pointer = esp + 4;
        if(count >0){
                for(i=0;i<count;i++){
                        check_address(pointer);
                        arg[i] = *(int*)pointer;
                        pointer = pointer + 4;
                }
        }
}*/
void halt(void){
        shutdown_power_off();
}
void exit(int status){
	struct list_elem *list;	
	struct thread *t;
     
	printf("%s: exit(%d)\n", thread_name(),status);
	
	thread_current()->exit_code = status;
	
	for(int i=3;i<128;i++){
		if(thread_current()->fd[i] !=NULL) close(i);
	}
	for(list = list_begin(&thread_current()->child_list);list != list_end(&thread_current()->child_list);list=list_next(list)){
		t = list_entry(list,struct thread, child_elem);
		process_wait(t->tid);
	}
	thread_exit();
}
int write(int fd,const void *buffer, unsigned size){
	lock_acquire(&file_lock);
	if(fd == STDOUT){
		putbuf(buffer,size);
		lock_release(&file_lock);
		return size;
	}
	else if(fd > 2){	
		if(thread_current()->fd[fd]==NULL){
			lock_release(&file_lock);
			exit(-1);
		}
		struct file * cc = thread_current()->fd[fd];
		if(cc->deny_write){
			file_deny_write(thread_current()->fd[fd]);
		}
//		page_pinning_buffers(buffer,size);
		size= file_write(thread_current()->fd[fd],buffer,size);
	}

	lock_release(&file_lock);
	return size;
}
tid_t exec(const char *cmd_line){
    //    tid_t tid;
  //      struct thread *child;
//        char *copy;
        //process_execut()함수를 호출해서 자식 프로세스 생성
//        if((tid = (tid_t)process_execute(cmd_line)) == TID_ERROR)
 //               return TID_ERROR;
//        copy = palloc_get_page (0);
//        if(copy == NULL)
 //               return TID_ERROR;

  //      strlcpy(copy,cmd_line,PGSIZE);
//      tid = thread_create(file_name,PRI_DEFAULT,start_process,copy);
//      if(tid == TID_ERROR){
//              palloc_free_page(copy);
//      } 
 //     child = get_child(tid);
  //    ASSERT(child);
    
    //  sema_down (&child -> sema_ready);        
     // if(!child->load)
      //        return TID_ERROR;
       // return tid;
//      return process_execute(cmd_line);
//      struct file *file = NULL;
// 	int index = 0;
//	printf("cmd_line : %s\n",cmd_line);
//	char temp[256];
//	file_name_parse(temp,cmd_line);
//	file = filesys_open(temp);
//	if(file == NULL)
//		return -1;
//	tid_t result = process_execute(cmd_line);
//	return (tid_t)result;
	struct file *f;
	int i=0;
	char file_name[128];
	while(cmd_line[i] != ' ' && cmd_line[i]!='\0'){
		file_name[i] = cmd_line[i];
		i++;
	}
	file_name[i] = '\0';
	f = filesys_open(file_name);
	if(f==NULL) return -1;
	return process_execute(cmd_line);
}


int wait (tid_t tid){
        //thread 
        //struct thread child;
        //child = thread_get_child(tid);
        //if(is_thread(child))
        //thread_yield()
        return process_wait(tid);
}



int read(int fd, void *buffer, unsigned size){
	if(!is_user_vaddr(buffer))exit(-1);
	lock_acquire(&file_lock);
	if(thread_current()->fd[fd]==NULL)exit(-1);
	int kk = -1;

        if(fd == STDIN){
                
		unsigned temp = size;
                while(temp--){
			*((char*)buffer++) = input_getc();            
		}
		kk = size;
         } 
	else if (fd>2){
		struct thread *tt = thread_current();
		if(thread_current()->fd[fd] == NULL){
			exit(-1);
		}
//		page_pinning_buffers(buffer,size);
		kk = file_read(tt->fd[fd],buffer,size);
	}  

	lock_release(&file_lock);
	return kk;
}

int fibonacci(int n){
     if (n<2)
	return n;
     int a = 0;
     int b = 1;
     int temp = 0;
     for(int i=0;i<n-1;i++){
	temp = b;
        b = a+b;
        a = temp;
	
     }
     return b;

}

int max_of_four_int(int a, int b, int c, int d){
	int max = a;

	if(b>max) max = b;
	if(c>max) max = c;
	if(d>max) max = d;
	return max;
}

bool create(const char *file, unsigned initial_size){
	if(file == NULL) exit(-1);
	return filesys_create(file,initial_size);

}

bool remove(const char *file){
	if(file == NULL) exit(-1);
	return filesys_remove(file);

}

int filesize(int fd){
	if(thread_current()->fd[fd] == NULL) exit(-1);
	return file_length(thread_current()->fd[fd]);
}

int open(const  char *file){
	if(file==NULL) exit(-1);


	int fd = -1;
	lock_acquire(&file_lock);
	struct file *open_f = filesys_open(file);
	if(open_f == NULL) fd = -1;
	else{	
		for(int i=3;i<128;i++){
			if((thread_current()->fd[i]==NULL) && (strcmp(thread_name(),file)==0))
				file_deny_write(open_f);
			if(thread_current()->fd[i] == NULL){
				thread_current()->fd[i] = open_f;
				fd = i;	
				break;
			}
		}
	}
	lock_release(&file_lock);
	return fd;
}


void seek(int fd, unsigned position){
	if(thread_current()->fd[fd] == NULL) exit(-1);
 	file_seek(thread_current()->fd[fd],position);

}

void close(int fd){
	if(thread_current()->fd[fd]==NULL)exit(-1);
	struct file* ff = thread_current()->fd[fd];
	thread_current()->fd[fd] = NULL;
	file_close(ff);
}

unsigned tell(int fd){
 	if (thread_current()->fd[fd]==NULL) exit(-1);	
	return file_tell(thread_current()->fd[fd]);	
}
/*
int mmap(int fd, void *addr){
	if((uint32_t)addr % PGSIZE != 0) return -1;
	struct file *file = file_reopn(thread_current()->fd[fd]);
	thread_current()->mmapid++;
	size_t read_bytes = file_length(file);
	thread_current()->msize[fd] = read_bytes;
	
}*/

struct mapping{

	struct list_elem elem;
	int handle;
	struct file *file;
	uint8_t *base;
	size_t page_cnt;
};
static void unmap(struct mapping *m);
static struct mapping* lookup_mapping(int handle){
	struct thread *cur = thread_current();
	struct list_elem *e;
	for(e = list_begin (&cur->mappings); e != list_end(&cur->mappings);e=list_next(e)){
		struct mapping *m = list_entry(e, struct mapping, elem);
		if(m->handle == handle) return m;
	}
	thread_exit();
}

/*
int mmap(int fd, void *addr){

	
	
		if((fd<2)||(fd>64)||thread_current()->fd[fd]==NULL)
		{
			return -1;
		}

		if(*(uint32_t *)addr>PHYS_BASE||(*(char **)addr==NULL))
		{
			return -1;
		}

		if(pg_ofs(addr)!=0||file_length(thread_current()->fd[fd])==0)
		{
			return -1;
		}
		if(thread_current()->page_table!=NULL)
		{

			struct page_entry check;
			check.vaddr=pg_round_down(addr);
			struct hash_elem *he = hash_find(&thread_current()->hash, &check.hash_elem);
			if (he!=NULL)
			{
				return -1;
			}
		}

		lock_acquire(&file_lock);
		struct file* openedfile = file_reopen(thread_current()->fd[fd]);
		lock_release(&file_lock);
		// thread_current()->mmaptable[thread_current()->nextmmapfd]=openedfile;
		thread_current()->nexthandle++;



		off_t remain = file_length(openedfile), already=0;

		while(remain>0)
		{
			off_t read_bytes, zero_bytes;
			if (remain>PGSIZE)
			{
				read_bytes=PGSIZE;
				zero_bytes=0;
				remain-=PGSIZE;
			}
			else
			{
				read_bytes=remain;
				zero_bytes=PGSIZE-read_bytes;
				remain-=read_bytes;
			}
			struct page_entry *new = allocate_page(openedfile, already, addr+already,
				read_bytes, zero_bytes, true);
			if(new==NULL)
			{
				
				if(openedfile!=NULL)
				{
					lock_acquire(&file_lock);
					file_close(openedfile);
					lock_release(&file_lock);
				}
				return -1;
			}
			new->mapid=thread_current()->next_mapid;
			new->mmapfd=fd;
			already+=PGSIZE;
		}

		f->eax=(mapid_t)thread_current()->next_mapid;
		thread_current()->mmaptable[thread_current()->next_mapid]=openedfile;
		// struct mmapentry* newme = (struct mmapentry*)malloc(sizeof (struct mmapentry));
		// newme->mmapfile=openedfile;

		// list_push_back(&thread_current()->mmaplist,&newme->me_elem);

		thread_current()->next_mapid++;
		return thread_cueernt()->next_mapid -1;
}*/
 int mmap(int fd, void *addr){

//	lock_acquire(&file_lock);

	struct file *file = file_reopen(thread_current()->fd[fd]);
	ASSERT(file != NULL);
	
	if((uint32_t)addr % PGSIZE != 0) return -1;

	uint32_t ofs = 0;	
	size_t read_bytes = file_length(file);
	size_t zero_bytes = PGSIZE - (read_bytes % PGSIZE);
	uint8_t *userpage = addr;

	thread_current()->msize[fd] = read_bytes;
	
	file_seek(file, 0);
	
	while(read_bytes > 0 || zero_bytes > 0){
		size_t page_read_bytes = read_bytes < PGSIZE ? read_bytes : PGSIZE;
		size_t page_zero_bytes = PGSIZE - page_read_bytes;
		
		uint8_t *kerpage = palloc_get_page (PAL_USER);
		while(kerpage == NULL){
			struct hash_iterator iter;
			struct page_entry *pp = NULL;
			while(1){
				hash_first(&iter, &pp);
			}
			kerpage = palloc_get_page(PAL_USER);

		}
	
		int temp = file_read(file, kerpage, page_read_bytes);
		if (temp != (int)page_read_bytes){
			palloc_free_page (kerpage);
			return -1;
		}
	
		memset(kerpage + page_read_bytes, 0, page_zero_bytes);
	
		pagedir_set_page (thread_current()->pagedir, userpage, kerpage, true);
		page_insert(userpage, kerpage, true);;
		
		read_bytes = read_bytes - page_read_bytes;
		zero_bytes = zero_bytes - page_zero_bytes;
		userpage += PGSIZE;
	
	}
	thread_current()->mbuffer[fd] = addr;
//	lock_release(&file_lock);
	return fd;

}
  //struct file_descriptor *file_des = lookup_fd (fd);
 /* if(!is_user_vaddr(addr)||fd == STDOUT_FILENO||fd == STDIN_FILENO||((int) addr % PGSIZE) != 0||addr == NULL)
    return -1;
 
  struct file *f = file_reopen (thread_current()->fd[fd]);
//  thread_current()->msize[fd] = read_bytes;

  int32_t ofs = 0;
  int read_bytes = file_length(f);
  if(read_bytes == 0)
    return -1;
//  thread_current()->msize[fd] = read_bytes;
  thread_current()->mmapid++;
  //struct list_elem *e;
  //for(e = list_begin (&thread_current()->page_table);e != list_end (&thread_current()->page_table);e = list_next (e)){
  //  if(list_entry(e,struct page_entry,elem)->user_page == addr)
  //    return -1;
 // }

  while (read_bytes > 0) {
      size_t page_read_bytes = read_bytes < PGSIZE ? read_bytes : PGSIZE;
      size_t page_zero_bytes = PGSIZE - page_read_bytes;

      struct page_entry *spte = malloc(sizeof(struct page_entry));
      spte->is_load = 0;
      spte->code_or_data = 2;
      spte->file = f;
      spte->ofs = ofs;
      spte->vaddr = addr;
      spte->read_bytes = page_read_bytes;
      spte->zero_bytes = page_zero_bytes;
      spte->writable = true;
      list_push_back(&thread_current()->page_table,&spte->elem);

     
      read_bytes -= page_read_bytes;
      ofs += page_read_bytes;       
      addr += PGSIZE;

      
      struct mmap_elem *mmape = malloc(sizeof(struct mmap_elem));
      mmape->mpt = spte;
      mmape->mmapid = thread_current()->mmapid;
      list_push_back(&thread_current()->mmap_list,&mmape->elem);
 }
  return thread_current()->mmapid;
 // return fd;
*/
 //struct file_decriptor *ff = lookup_fd (fd);
/* struct mapping *map = malloc(sizeof *map);	
 size_t offset;
 off_t length;

 if(map == NULL || addr == NULL || pg_ofs(addr) != 0) return -1;

	map->handle = thread_current()->next_handle++;
	lock_acquire(&file_lock);
	map->file = file_reopen(thread_current()->fd[fd]);
	lock_release(&file_lock);
	if(map->file== NULL){
		free(map);
		return -1;
	}
	map->base = addr;
	map->page_cnt = 0;
	list_push_front(&thread_current()->mappings, &map->elem);
	offset = 0;
	lock_acquire(&file_lock);
	length = file_length(map->file);
	lock_release(&file_lock);
	while(length > 0){
//		struct page_entry *page = page_insert((uint8_t*) addr + offset, false);
		struct page_entry *page = malloc(sizeof(struct page_entry));
		if(page==NULL){
			unmap(map);
			return -1;
		}
		page->writable = false;
		page->file = map->file;
		page->ofs = offset;
		page->read_bytes = length >= PGSIZE ? PGSIZE: length;
		offset += page->read_bytes;
		length -= page->read_bytes;
		map->page_cnt++;
	}
	return map->handle;
*/
//}

void munmap(int mapping){

	int i;
	int size = filesize(mapping);
	void *buffer = thread_current()->mbuffer[mapping];

	ASSERT(buffer != NULL);
	lock_acquire(&file_lock);

	uint32_t bb = ((uint32_t) buffer >> 12 ) << 12;
	int ss = size + (uint32_t) buffer - bb;
	uint32_t pid = thread_tid();
	
	while(ss > 0){
		struct page_entry *pp = get_page_entry((void*)bb, pid);
		////lock
		pp->pinned = true;
	
		swap_in((void*)bb, pp->swap_index);
		
		bb = bb + PGSIZE;
		size = size - PGSIZE;
	}
	file_write(thread_current()->fd[mapping], buffer, size);
	lock_release(&file_lock);
	return;
}
/*	struct list_elem *e;
  for (e = list_begin(&thread_current()->mmap_list);e != list_end(&thread_current()->mmap_list);e = list_next(e)){
    if(list_entry(e,struct mmap_elem,elem)->mmapid == mapping){
      struct mmap_elem *mmape = list_entry(e,struct mmap_elem,elem);
      if(pagedir_is_dirty(thread_current()->pagedir, mmape->mpt->vaddr)){
	lock_acquire(&file_lock);
	file_write_at(mmape->mpt->file, mmape->mpt->vaddr,mmape->mpt->read_bytes, mmape->mpt->ofs);
	lock_release(&file_lock);
        frame_free(pagedir_get_page(thread_current()->pagedir, mmape->mpt->vaddr));
        pagedir_clear_page(thread_current()->pagedir, mmape->mpt->vaddr);
        list_remove(&mmape->elem);
        list_remove(&mmape->mpt->elem);
      }
      list_remove(&mmape->mpt->elem);
      list_remove(&mmape->elem);
    }
  }
*/


/*	mapid_t mapid = *(mapid_t *)mapping;

		struct hash_iterator i;

		hash_first (&i, &thread_current()->hash);
		hash_next(&i);
		while (hash_cur (&i))
		{
			struct sup_page_table_entry *spte = hash_entry (hash_cur (&i), struct sup_page_table_entry, hash_elem);
			if((mapid_t)spte->mapid==mapid)
			{

				if(pagedir_is_dirty(thread_current()->pagedir,spte->user_vaddr))
				{
					spte_set_dirty(spte->user_vaddr,true);
					void* target = (void *)((char *)spte->file + spte->ofs);
					lock_acquire(&handlesem);
					struct file* filetowrite = thread_current()->fdtable[spte->mmapfd];
					off_t size = strlen((char *)spte->user_vaddr);
					file_seek(spte->file,0);
					off_t temppos = file_tell(spte->file);
					off_t writebytes = file_write(spte->file,spte->user_vaddr, strlen((char *)spte->user_vaddr));
					file_seek(spte->file,temppos);
					lock_release(&handlesem);
				}
				hash_next(&i);
				file_close(spte->file);
				hash_delete(&thread_current()->hash,&spte->hash_elem);
				free(spte);
			}
			else
			{
				hash_next(&i);
			}

		}


//	struct mapping *map = lookup_mapping(mapping);
//	unmap(map);
//	return 0;
}

static void unmap(struct mapping *m){

	list_remove(&m->elem);
	
	for(int i=0;i<m->page_cnt;i++){
		if(pagedir_is_dirty(thread_current()->pagedir, ((const void*)((m->base) + (PGSIZE * i))))){
			lock_acquire(&file_lock);
			file_write_at(m->file, (const void*)(m->base + (PGSIZE * i)), (PGSIZE*(m->page_cnt)),(PGSIZE*i));
			lock_release(&file_lock);
		}
	}
*/
/*	for(int i=0;i<m->page_cnt;i++){
	//	page_delete((void*)((m->base) + (PGSIZE * i)));
		void* vaddr = ((m->base) + (PGSIZE * i));
		struct page_entry *p = page_for_addr(vaddr);
		ASSERT(p != NULL);
		
		if(p->frame){
			struct frame *f = p->frame;
			
//		}
	}*/
//}
